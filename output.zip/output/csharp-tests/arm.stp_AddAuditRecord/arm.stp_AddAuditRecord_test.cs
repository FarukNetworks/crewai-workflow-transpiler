
using System;
using System.Threading.Tasks;
using Moq;
using Xunit;
using YourNamespace.Repositories; // Ensure this points to your actual namespace
using YourNamespace.Models; // Ensure this points to your actual namespace
using YourNamespace.Services; // Ensure this points to your actual namespace

public class AuditRecordServiceTests
{
    private readonly Mock<IAuditRecordRepository> _mockRepository;
    private readonly AuditRecordService _service;

    public AuditRecordServiceTests()
    {
        _mockRepository = new Mock<IAuditRecordRepository>();
        _service = new AuditRecordService(_mockRepository.Object);
    }

    [Fact]
    public async Task AddAuditRecord_TransformsCollectionToShare()
    {
        Guid actionedBy = Guid.NewGuid();
        string affectedItem = "unique-item-id-1701011";
        string itemType = "Collection";
        var auditRecord = new AuditRecord
        {
            ActionedBy = actionedBy,
            AffectedItem = affectedItem,
            ItemType = itemType
        };

        _mockRepository.Setup(repo => repo.AddAuditRecordAsync(It.Is<AuditRecord>(record => record.ItemType == "Share")))
                       .Returns(Task.CompletedTask);

        await _service.AddAuditRecordAsync(auditRecord);

        _mockRepository.Verify(repo => repo.AddAuditRecordAsync(It.Is<AuditRecord>(record => record.ItemType == "Share")), Times.Once);
    }

    [Fact]
    public async Task AddAuditRecord_AssetOwnerIsFetchedWhenNull()
    {
        Guid actionedBy = Guid.NewGuid();
        string affectedItem = "unique-id-for-null-test-1701011";
        string itemType = "Account";
        var auditRecord = new AuditRecord
        {
            ActionedBy = actionedBy,
            AffectedItem = affectedItem,
            ItemType = itemType,
            AssetOwner = null
        };

        string expectedOwner = "expected-owner";
        _mockRepository.Setup(repo => repo.FetchAssetOwnerAsync(affectedItem, itemType))
                       .ReturnsAsync(expectedOwner);

        _mockRepository.Setup(repo => repo.AddAuditRecordAsync(It.Is<AuditRecord>(record => record.AssetOwner == expectedOwner)))
                       .Returns(Task.CompletedTask);

        await _service.AddAuditRecordAsync(auditRecord);

        _mockRepository.Verify(repo => repo.AddAuditRecordAsync(It.Is<AuditRecord>(record => record.AssetOwner == expectedOwner)), Times.Once);
    }

    [Fact]
    public async Task AddAuditRecord_TransactionRollbackOnError()
    {
        Guid actionedBy = Guid.NewGuid();
        string invalidItemId = "invalid-id-1701011";
        string itemType = "Account";
        var auditRecord = new AuditRecord
        {
            ActionedBy = actionedBy,
            AffectedItem = invalidItemId,
            ItemType = itemType
        };

        _mockRepository.Setup(repo => repo.AddAuditRecordAsync(auditRecord))
                       .Throws(new InvalidOperationException());

        await Assert.ThrowsAsync<InvalidOperationException>(() => _service.AddAuditRecordAsync(auditRecord));

        _mockRepository.Verify(repo => repo.RevertTransactionAsync(auditRecord), Times.Once);
    }
}
