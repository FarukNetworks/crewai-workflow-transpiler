
using System;
using Moq;
using Xunit;
using MyNamespace.Repositories;
using MyNamespace.Models;

public class EmailDetailsRepositoryTests
{
    private readonly Mock<IDatabaseContext> _mockDbContext;
    private readonly IEmailDetailsRepository _emailDetailsRepository;

    public EmailDetailsRepositoryTests()
    {
        _mockDbContext = new Mock<IDatabaseContext>();
        _emailDetailsRepository = new EmailDetailsRepository(_mockDbContext.Object);
    }

    [Fact]
    public void ValidCampaignWithRecipient_ShouldReturnEmailDetails()
    {
        const int campaignId = 1;
        var userStsGuid = new Guid("A1B2C3D4-E5F6-7890-ABCD-EF1234567892");
        
        var emailHistory = new EmailHistory
        {
            CampaignId = campaignId,
            Recipient = userStsGuid,
            Sender = "sender1@example.com",
            Timestamp = DateTime.Now,
            CampaignEmailTemplateId = 1
        };
        var campaignEmailTemplate = new CampaignEmailTemplates
        {
            Id = 1,
            CampaignId = campaignId,
            WorkflowStep = "Step1",
            ccManager = "manager1@example.com"
        };

        _mockDbContext.Setup(db => db.EmailHistories).ReturnsDbSet(new[] { emailHistory });
        _mockDbContext.Setup(db => db.CampaignEmailTemplates).ReturnsDbSet(new[] { campaignEmailTemplate });

        var result = _emailDetailsRepository.GetEmailDetails(campaignId, userStsGuid);

        Assert.NotNull(result);
        Assert.Equal(userStsGuid, result.Recipient);
    }

    [Fact]
    public void NullRecipient_ShouldReturnEmailDetailsWithNullRecipient()
    {
        const int campaignId = 2;
        
        var emailHistory = new EmailHistory
        {
            CampaignId = campaignId,
            Recipient = null,
            Sender = "sender2@example.com",
            Timestamp = DateTime.Now,
            CampaignEmailTemplateId = 2
        };
        var campaignEmailTemplate = new CampaignEmailTemplates
        {
            Id = 2,
            CampaignId = campaignId,
            WorkflowStep = "Step2",
            ccManager = "manager2@example.com"
        };

        _mockDbContext.Setup(db => db.EmailHistories).ReturnsDbSet(new[] { emailHistory });
        _mockDbContext.Setup(db => db.CampaignEmailTemplates).ReturnsDbSet(new[] { campaignEmailTemplate });

        var result = _emailDetailsRepository.GetEmailDetails(campaignId, null);

        Assert.NotNull(result);
        Assert.Null(result.Recipient);
    }
}
