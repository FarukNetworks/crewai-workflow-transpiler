public class AuditRecordService
{
    private readonly IAuditRecordRepository _repository;

    public AuditRecordService(IAuditRecordRepository repository)
    {
        _repository = repository;
    }

    public async Task AddAuditRecordAsync(AuditRecord record)
    {
        if (record.ItemType == "Collection")
        {
            record.ItemType = "Share";
        }
        else if (record.ItemType == "Exchange")
        {
            record.ItemType = "Mailbox";
        }
        else if (record.ItemType == "Share")
        {
            record.ItemType = "Collection";
        }
        else if (record.ItemType == "Service Account")
        {
            record.ItemType = "Account";
        }

        if (string.IsNullOrEmpty(record.AssetOwner.ToString()) 
            && new[] { "Account", "Group", "Service Account", "Group Policy" }.Contains(record.ItemType))
        {
            record.AssetOwner = Guid.Parse(await _repository.FetchAssetOwnerAsync(record.AffectedItem, record.ItemType));
        }
        else if (string.IsNullOrEmpty(record.AssetOwner.ToString()) 
                 && new[] { "Application", "Server", "AppRole", "Share", "Exchange" }.Contains(record.ItemType))
        {
            record.AssetOwner = Guid.Parse(await _repository.FetchAssetOwnerAsync(record.AffectedItem, record.ItemType));
        }

        record.Timestamp = DateTime.UtcNow;

        try
        {
            await _repository.AddAuditRecordAsync(record);
        }
        catch (Exception)
        {
            await _repository.RevertTransactionAsync(record);
            throw;
        }
    }
}