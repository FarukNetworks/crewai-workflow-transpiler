public interface IAuditRecordRepository
{
    Task AddAuditRecordAsync(AuditRecord auditRecord);
    Task<string> FetchAssetOwnerAsync(string affectedItem, string itemType);
    Task RevertTransactionAsync(AuditRecord auditRecord);
}