public class AuditRecord
{
    public int CampaignId { get; set; }
    public DateTime Timestamp { get; set; }
    public Guid ActionedBy { get; set; }
    public string? AffectedItem { get; set; }
    public string? ItemType { get; set; }
    public string? EventDescription { get; set; }
    public string? PreviousValue { get; set; }
    public string? NewValue { get; set; }
    public Guid? AssetOwner { get; set; }
    public string? AssetName { get; set; }
}