namespace MyNamespace.Models
{
    public class CampaignEmailTemplates
    {
        public int Id { get; set; }
        public int CampaignId { get; set; }
        public string WorkflowStep { get; set; }
        public string ccManager { get; set; }
    }
}