using System;

namespace MyNamespace.Models
{
    public class EmailHistory
    {
        public int CampaignId { get; set; }
        public Guid? Recipient { get; set; }
        public string Sender { get; set; }
        public DateTime Timestamp { get; set; }
        public int CampaignEmailTemplateId { get; set; }
        public string WorkflowStep { get; set; }
        public string ccManager { get; set; }
    }
}