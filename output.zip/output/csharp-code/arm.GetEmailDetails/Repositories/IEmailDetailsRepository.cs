using System;
using MyNamespace.Models;

namespace MyNamespace.Repositories
{
    public interface IEmailDetailsRepository
    {
        EmailHistory GetEmailDetails(int campaignId, Guid? userStsGuid);
    }
}