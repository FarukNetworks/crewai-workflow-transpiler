using System;
using System.Linq;
using MyNamespace.Models;

namespace MyNamespace.Repositories
{
    public class EmailDetailsRepository : IEmailDetailsRepository
    {
        private readonly IDatabaseContext _dbContext;

        public EmailDetailsRepository(IDatabaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public EmailHistory GetEmailDetails(int campaignId, Guid? userStsGuid)
        {
            var emailDetails = from eh in _dbContext.EmailHistories
                               join cet in _dbContext.CampaignEmailTemplates on new { eh.CampaignId, eh.CampaignEmailTemplateId } equals new { cet.CampaignId, cet.Id }
                               where eh.CampaignId == campaignId && (eh.Recipient == userStsGuid || userStsGuid == null)
                               select new EmailHistory
                               {
                                   CampaignId = eh.CampaignId,
                                   Recipient = eh.Recipient,
                                   Sender = eh.Sender,
                                   Timestamp = eh.Timestamp,
                                   CampaignEmailTemplateId = cet.Id,
                                   WorkflowStep = cet.WorkflowStep,
                                   ccManager = cet.ccManager
                               };

            return emailDetails.FirstOrDefault();
        }
    }
}