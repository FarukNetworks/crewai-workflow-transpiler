EXEC tSQLt.NewTestClass 'ArchiveCampaignTests';
GO
CREATE PROCEDURE ArchiveCampaignTests.[SetUp]
AS
BEGIN

    EXEC tSQLt.FakeTable 'dbo.ADobjectInfo';
    EXEC tSQLt.FakeTable 'arm.ArchivedCampaignResult';
    EXEC tSQLt.FakeTable 'arm.ArchivedCampaignAuditLog';
    EXEC tSQLt.FakeTable 'arm.Campaigns';
    EXEC tSQLt.FakeTable 'arm.CustomQuestions';


    EXEC tSQLt.SpyProcedure 'arm.stp_CampaignResults';


    EXEC tSQLt.SpyProcedure 'arm.stp_AddAuditRecord';
END;
GO
CREATE PROCEDURE ArchiveCampaignTests.[test_ArchiveCampaign_SuccessfulArchive_1623]
AS
BEGIN

    DECLARE @campaignId INT = 12345;
    DECLARE @archivedBy UNIQUEIDENTIFIER = NEWID();
    DECLARE @expectedSamAccountName NVARCHAR(100) = 'TestUser1623';


    INSERT INTO dbo.ADobjectInfo (STSGuid, SamAccountName)
    VALUES (@archivedBy, @expectedSamAccountName);

    INSERT INTO arm.Campaigns (Id, Name, Archived, ArchivedBy, ArchivedDate, CampaignStatus, Description)
    VALUES (@campaignId, 'Test Campaign 1623', 0, NULL, NULL, 'Active', 'Test Campaign for archiving');


    INSERT INTO arm.CustomQuestions (Id, CampaignScope, Question, QuestionType)
    VALUES (987, @campaignId, 'Test Question 1?', 'Multiple Choice');


    EXEC arm.stp_ArchiveCampaign @campaignId, @archivedBy;


    DECLARE @archived BIT, @actualArchivedBy UNIQUEIDENTIFIER;
    SELECT @archived = Archived, @actualArchivedBy = ArchivedBy
    FROM arm.Campaigns
    WHERE Id = @campaignId;

    DECLARE @archivedByStr NVARCHAR(36) = CONVERT(NVARCHAR(36), @archivedBy);
    DECLARE @actualArchivedByStr NVARCHAR(36) = CONVERT(NVARCHAR(36), @actualArchivedBy);
    
    EXEC tSQLt.AssertEquals 1, @archived, 'Campaign should be marked as archived.';
    EXEC tSQLt.AssertEquals @archivedByStr, @actualArchivedByStr, 'Campaign should be archived by the specified user.';


    SELECT TOP 1 @campaignId AS ExpectedCampaignId, cr.*
    INTO #expected_stp_CampaignResults_1623
    FROM arm.stp_CampaignResults_SpyProcedureLog cr;

    EXEC tSQLt.AssertEqualsTable '#expected_stp_CampaignResults_1623', 'arm.stp_CampaignResults_SpyProcedureLog', 'arm.stp_CampaignResults should be called once.';


    DECLARE @expectedDescription NVARCHAR(MAX) = 'Campaign Archived by ' + @expectedSamAccountName;
    SELECT TOP 1 @campaignId AS CampaignId, @expectedDescription AS Description, ar.*
    INTO #expected_stp_AddAuditRecord_1623
    FROM arm.stp_AddAuditRecord_SpyProcedureLog ar
    WHERE CampaignId = @campaignId
      AND Description = @expectedDescription;

    EXEC tSQLt.AssertEqualsTable '#expected_stp_AddAuditRecord_1623', 'arm.stp_AddAuditRecord_SpyProcedureLog', 'arm.stp_AddAuditRecord should be called with the correct parameters.';


    DECLARE @questionCampaignScope INT;
    SELECT @questionCampaignScope = CampaignScope
    FROM arm.CustomQuestions
    WHERE Id = 987;

    EXEC tSQLt.AssertEquals -1, @questionCampaignScope, 'CampaignScope for custom questions should be updated to -1.';
END;
GO
CREATE PROCEDURE ArchiveCampaignTests.[test_ArchiveCampaign_NonExistentCampaign_1624]
AS
BEGIN

    DECLARE @campaignId INT = 99999;
    DECLARE @archivedBy UNIQUEIDENTIFIER = NEWID();


    INSERT INTO dbo.ADobjectInfo (STSGuid, SamAccountName)
    VALUES (@archivedBy, 'TestUser1624');


    DELETE FROM arm.Campaigns WHERE Id = @campaignId;


    EXEC arm.stp_ArchiveCampaign @campaignId, @archivedBy;


    EXEC tSQLt.AssertEmptyTable 'arm.stp_CampaignResults_SpyProcedureLog', 'arm.stp_CampaignResults should not be called for non-existent campaign.';


    EXEC tSQLt.AssertEmptyTable 'arm.stp_AddAuditRecord_SpyProcedureLog', 'arm.stp_AddAuditRecord should not be called for non-existent campaign.';
END;
GO
CREATE PROCEDURE ArchiveCampaignTests.[test_ArchiveCampaign_NullArchivedBy_1625]
AS
BEGIN

    DECLARE @campaignId INT = 12346;
    DECLARE @archivedBy UNIQUEIDENTIFIER = NULL;
    
    EXEC tSQLt.FakeTable 'arm.Campaigns';
    
    EXEC tSQLt.AddColumn 'arm.Campaigns', 'Id', 'INT';
    EXEC tSQLt.AddColumn 'arm.Campaigns', 'Name', 'NVARCHAR(100)';
    EXEC tSQLt.AddColumn 'arm.Campaigns', 'Archived', 'BIT';
    EXEC tSQLt.AddColumn 'arm.Campaigns', 'ArchivedBy', 'UNIQUEIDENTIFIER';
    EXEC tSQLt.AddColumn 'arm.Campaigns', 'ArchivedDate', 'DATETIME';
    EXEC tSQLt.AddColumn 'arm.Campaigns', 'CampaignStatus', 'NVARCHAR(50)';
    EXEC tSQLt.AddColumn 'arm.Campaigns', 'Description', 'NVARCHAR(MAX)';
    
    INSERT INTO arm.Campaigns (Id, Name, Archived, ArchivedBy, ArchivedDate, CampaignStatus, Description)
    VALUES (@campaignId, 'Test Campaign 1625', 0, NULL, NULL, 'Active', 'Test Campaign for archiving with NULL archivedBy');

    -- Create spy procedures for the dependencies
    EXEC tSQLt.SpyProcedure 'arm.stp_CampaignResults';
    EXEC tSQLt.SpyProcedure 'arm.stp_AddAuditRecord';

    EXEC arm.stp_ArchiveCampaign @campaignId, @archivedBy;

    DECLARE @archived BIT;
    SELECT @archived = Archived
    FROM arm.Campaigns
    WHERE Id = @campaignId;

    EXEC tSQLt.AssertEquals 0, @archived, 'Campaign should NOT be archived with NULL archivedBy.';

    EXEC tSQLt.AssertEmptyTable 'arm.stp_CampaignResults_SpyProcedureLog', 'arm.stp_CampaignResults should not be called with NULL archivedBy.';
    EXEC tSQLt.AssertEmptyTable 'arm.stp_AddAuditRecord_SpyProcedureLog', 'arm.stp_AddAuditRecord should not be called with NULL archivedBy.';
END;
GO

CREATE PROCEDURE ArchiveCampaignTests.[test_ArchiveCampaign_InvalidUser_1626]
AS
BEGIN

    DECLARE @campaignId INT = 12347;
    DECLARE @archivedBy UNIQUEIDENTIFIER = NEWID();
    
    -- Creating the table if it doesn't exist
    IF OBJECT_ID('arm.Campaigns') IS NULL
    BEGIN
        CREATE TABLE arm.Campaigns (
            Id INT PRIMARY KEY,
            CampaignName NVARCHAR(255),
            Archived BIT,
            ArchivedBy UNIQUEIDENTIFIER NULL,
            ArchivedDate DATETIME NULL,
            CampaignStatus NVARCHAR(50),
            Description NVARCHAR(MAX)
        );
    END
    
    INSERT INTO arm.Campaigns (Id, CampaignName, Archived, ArchivedBy, ArchivedDate, CampaignStatus, Description)
    VALUES (@campaignId, 'Test Campaign 1626', 0, NULL, NULL, 'Active', 'Test Campaign for archiving with invalid user');

    IF OBJECT_ID('dbo.ADobjectInfo') IS NULL
    BEGIN
        CREATE TABLE dbo.ADobjectInfo (
            STSGuid UNIQUEIDENTIFIER PRIMARY KEY
        );
    END

    DELETE FROM dbo.ADobjectInfo WHERE STSGuid = @archivedBy;

    EXEC arm.stp_ArchiveCampaign @campaignId, @archivedBy;

    DECLARE @archived BIT;
    SELECT @archived = Archived
    FROM arm.Campaigns
    WHERE Id = @campaignId;

    EXEC tSQLt.AssertEquals 0, @archived, 'Campaign should NOT be archived with invalid user.';

    EXEC tSQLt.AssertEmptyTable 'arm.stp_CampaignResults_SpyProcedureLog', 'arm.stp_CampaignResults should not be called with invalid user.';
    EXEC tSQLt.AssertEmptyTable 'arm.stp_AddAuditRecord_SpyProcedureLog', 'arm.stp_AddAuditRecord should not be called with invalid user.';
END;

GO
CREATE PROCEDURE ArchiveCampaignTests.[test_ArchiveCampaign_AlreadyArchived_1627]
AS
BEGIN

    DECLARE @campaignId INT = 12348;
    DECLARE @archivedBy UNIQUEIDENTIFIER = NEWID();
    DECLARE @previousArchivedBy UNIQUEIDENTIFIER = NEWID();
    DECLARE @previousArchivedDate DATETIME = DATEADD(DAY, -1, GETDATE());


    INSERT INTO dbo.ADobjectInfo (STSGuid, SamAccountName)
    VALUES (@archivedBy, 'TestUser1627'), (@previousArchivedBy, 'PreviousUser1627');


    INSERT INTO arm.Campaigns (Id, Name, Archived, ArchivedBy, ArchivedDate, CampaignStatus, Description)
    VALUES (@campaignId, 'Test Campaign 1627', 1, @previousArchivedBy, @previousArchivedDate, 'Archived', 'Test Campaign already archived');


    EXEC arm.stp_ArchiveCampaign @campaignId, @archivedBy;


    DECLARE @actualArchivedBy UNIQUEIDENTIFIER, @actualArchivedDate DATETIME;
    SELECT @actualArchivedBy = ArchivedBy, @actualArchivedDate = ArchivedDate
    FROM arm.Campaigns
    WHERE Id = @campaignId;

    EXEC tSQLt.AssertEquals @expected = CONVERT(NVARCHAR(36), @previousArchivedBy), 
                           @actual = CONVERT(NVARCHAR(36), @actualArchivedBy),
                           @message = 'ArchivedBy should not change for an already archived campaign.';


    EXEC tSQLt.AssertEmptyTable @TableName = 'arm.stp_CampaignResults_SpyProcedureLog', @Message = 'arm.stp_CampaignResults should not be called for already archived campaign.';
    EXEC tSQLt.AssertEmptyTable @TableName = 'arm.stp_AddAuditRecord_SpyProcedureLog', @Message = 'arm.stp_AddAuditRecord should not be called for already archived campaign.';
END;
GO
CREATE PROCEDURE ArchiveCampaignTests.[test_ArchiveCampaign_WithCustomQuestions_1628]
AS
BEGIN

    DECLARE @campaignId INT = 12349;
    DECLARE @archivedBy UNIQUEIDENTIFIER = NEWID();


    INSERT INTO dbo.ADobjectInfo (STSGuid, SamAccountName)
    VALUES (@archivedBy, 'TestUser1628');

    INSERT INTO arm.Campaigns (Id, Name, Archived, ArchivedBy, ArchivedDate, CampaignStatus, Description)
    VALUES (@campaignId, 'Test Campaign 1628', 0, NULL, NULL, 'Active', 'Test Campaign with custom questions');


    INSERT INTO arm.CustomQuestions (Id, CampaignScope, Question, QuestionType)
    VALUES
        (1001, @campaignId, 'Question 1?', 'Text'),
        (1002, @campaignId, 'Question 2?', 'Multiple Choice'),
        (1003, @campaignId, 'Question 3?', 'Checkbox'),
        (1004, @campaignId, 'Question 4?', 'Rating');


    EXEC arm.stp_ArchiveCampaign @campaignId, @archivedBy;


    DECLARE @archived BIT;
    SELECT @archived = Archived
    FROM arm.Campaigns
    WHERE Id = @campaignId;

    EXEC tSQLt.AssertEquals 1, @archived, 'Campaign should be marked as archived.';


    SELECT Id, CampaignScope
    INTO #actual_custom_questions_1628
    FROM arm.CustomQuestions
    WHERE Id IN (1001, 1002, 1003, 1004);


    CREATE TABLE #expected_custom_questions_1628 (Id INT, CampaignScope INT);
    INSERT INTO #expected_custom_questions_1628 (Id, CampaignScope)
    VALUES
        (1001, -1),
        (1002, -1),
        (1003, -1),
        (1004, -1);

    EXEC tSQLt.AssertEqualsTable '#expected_custom_questions_1628', '#actual_custom_questions_1628',
                                'All custom questions should have CampaignScope updated to -1.';
END;
GO
CREATE PROCEDURE ArchiveCampaignTests.[test_ArchiveCampaign_MaxCampaignId_1629]
AS
BEGIN

    DECLARE @campaignId INT = 2147483647;
    DECLARE @archivedBy UNIQUEIDENTIFIER = NEWID();


    INSERT INTO dbo.ADobjectInfo (STSGuid, SamAccountName)
    VALUES (@archivedBy, 'TestUser1629');

    INSERT INTO arm.Campaigns (Id, CampaignName, Archived, ArchivedBy, ArchivedDate, CampaignStatus, Description)
    VALUES (@campaignId, 'Test Campaign 1629', 0, NULL, NULL, 'Active', 'Test Description 1629');

END;
GO
