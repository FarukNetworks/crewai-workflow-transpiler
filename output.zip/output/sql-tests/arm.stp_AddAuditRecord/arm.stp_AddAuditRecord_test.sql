DECLARE @dbName NVARCHAR(100) = 'cases_' + CONVERT(NVARCHAR(20), CAST(CAST(GETDATE() AS FLOAT) AS INT));

IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = @dbName)
BEGIN
    EXEC('CREATE DATABASE ' + @dbName + ';');
END

EXEC('USE ' + @dbName + ';');

-- Ensure test class name is unique using a timestamp
DECLARE @testClass NVARCHAR(100) = 'teststp_AddAuditRecord_' + CONVERT(NVARCHAR(20), CAST(CAST(GETDATE() AS FLOAT) AS INT));
EXEC ('EXEC tSQLt.NewTestClass ''' + @testClass + ''';');

-- Ensure stored procedure name is unique using a timestamp
DECLARE @procName NVARCHAR(100) = '[arm].[stp_AddAuditRecord_' + CONVERT(NVARCHAR(20), CAST(CAST(GETDATE() AS FLOAT) AS INT)) + ']';

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(@procName) AND type in (N'P', N'PC'))
BEGIN
    EXEC('CREATE PROCEDURE ' + @procName + ' AS BEGIN PRINT ''This is a dummy procedure.'' END');
END

-- Ensure test procedure name is unique using a timestamp
DECLARE @testProc NVARCHAR(100) = '[' + @testClass + '].[test_AddsRecordSuccessfully_' + CONVERT(NVARCHAR(20), CAST(CAST(GETDATE() AS FLOAT) AS INT)) + ']';
DECLARE @uniqueTableName NVARCHAR(100) = 'arm.AuditTable_' + CONVERT(NVARCHAR(20), CAST(CAST(GETDATE() AS FLOAT) AS INT));

EXEC('
CREATE PROCEDURE ' + @testProc + '
AS
BEGIN
    EXEC tSQLt.FakeTable ''' + @uniqueTableName + ''', ''no check'', ''id, eventType, eventDescription'';

    INSERT INTO ' + @uniqueTableName + ' (id, eventType, eventDescription)
    VALUES (1, ''Test Event Type_'' + CONVERT(NVARCHAR(20), CAST(CAST(GETDATE() AS FLOAT) AS INT)), ''Test Event Description_'' + CONVERT(NVARCHAR(20), CAST(CAST(GETDATE() AS FLOAT) AS INT)));

    EXEC ' + @procName + ';

    DECLARE @expectedTable TABLE (id INT, eventType NVARCHAR(100), eventDescription NVARCHAR(255));
    INSERT INTO @expectedTable (id, eventType, eventDescription) 
    VALUES (1, ''Test Event Type_'' + CONVERT(NVARCHAR(20), CAST(CAST(GETDATE() AS FLOAT) AS INT)), ''Test Event Description_'' + CONVERT(NVARCHAR(20), CAST(CAST(GETDATE() AS FLOAT) AS INT)));
    
    EXEC tSQLt.AssertEqualsTable @expectedTable, ''' + @uniqueTableName + ''';
END
');

EXEC('DROP PROCEDURE IF EXISTS ' + @procName + ';');
GO
CREATE PROCEDURE [teststp_AddAuditRecord_FakeCampaignAuditLog_1701011_123456_1701011]
AS
BEGIN
    CREATE TABLE #CampaignAuditLog_1701011_123456 (
        CampaignId INT,
        Timestamp DATETIME,
        ActionedBy UNIQUEIDENTIFIER,
        AffectedItem NVARCHAR(255),
        ItemType NVARCHAR(50),
        EventDescription NVARCHAR(MAX),
        PreviousValue NVARCHAR(MAX),
        NewValue NVARCHAR(MAX),
        AssetOwner NVARCHAR(255),
        AssetName NVARCHAR(255)
    );
END;


CREATE PROCEDURE [teststp_AddAuditRecord_test_InsertAuditRecord_TransformToShare_1701011]
AS
BEGIN
    DECLARE @ActionedBy UNIQUEIDENTIFIER = NEWID();
    DECLARE @ItemId NVARCHAR(255) = 'unique-item-id-1701011';
    EXECUTE [teststp_AddAuditRecord_FakeCampaignAuditLog_1701011_123456_1701011];
    EXEC ARM.stp_AddAuditRecord
        @ActionedBy = @ActionedBy,
        @ItemId = @ItemId,
        @ItemType = 'Collection';
    EXEC tSQLt.AssertEqualsString 'Share',
    (SELECT ItemType FROM #CampaignAuditLog_1701011_123456 WHERE AffectedItem = @ItemId AND ActionedBy = @ActionedBy);
END;


CREATE PROCEDURE [teststp_AddAuditRecord_test_InsertAuditRecord_UnchangedShare_1701011]
AS
BEGIN
    DECLARE @ActionedBy UNIQUEIDENTIFIER = NEWID();
    DECLARE @ItemId NVARCHAR(255) = 'item-id-unique-1701011';
    EXECUTE [teststp_AddAuditRecord_FakeCampaignAuditLog_1701011_123456_1701011];
    EXEC ARM.stp_AddAuditRecord
        @ActionedBy = @ActionedBy,
        @ItemId = @ItemId,
        @ItemType = 'Share';
    EXEC tSQLt.AssertEqualsString 'Share',
    (SELECT ItemType FROM #CampaignAuditLog_1701011_123456 WHERE AffectedItem = @ItemId AND ActionedBy = @ActionedBy);
END;


CREATE PROCEDURE [teststp_AddAuditRecord_test_InsertAuditRecord_NullAssetOwner_1701011]
AS
BEGIN
    DECLARE @ActionedBy UNIQUEIDENTIFIER = NEWID();
    DECLARE @ItemId NVARCHAR(255) = 'unique-id-for-null-test-1701011';
    EXECUTE [teststp_AddAuditRecord_FakeCampaignAuditLog_1701011_123456_1701011];
    EXEC ARM.stp_AddAuditRecord
        @ActionedBy = @ActionedBy,
        @ItemId = @ItemId,
        @ItemType = 'Account',
        @AssetOwner = NULL;
    EXEC tSQLt.AssertEqualsString 'expected-owner',
    (SELECT AssetOwner FROM #CampaignAuditLog_1701011_123456 WHERE AffectedItem = @ItemId AND ActionedBy = @ActionedBy);
END;


CREATE PROCEDURE [teststp_AddAuditRecord_test_InsertAuditRecord_TransactionRollback_1701011]
AS
BEGIN
    DECLARE @ActionedBy UNIQUEIDENTIFIER = NEWID();
    DECLARE @InvalidItemId NVARCHAR(255) = 'invalid-id-1701011';
    EXECUTE [teststp_AddAuditRecord_FakeCampaignAuditLog_1701011_123456_1701011];
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC ARM.stp_AddAuditRecord
            @ActionedBy = @ActionedBy,
            @ItemId = @InvalidItemId,
            @ItemType = 'Account';
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
    END CATCH;
    EXEC tSQLt.AssertEquals 0,
    (SELECT COUNT(*) FROM #CampaignAuditLog_1701011_123456 WHERE AffectedItem = @InvalidItemId);
END;

GO
