DECLARE @Suffix NVARCHAR(10) = CONVERT(NVARCHAR(10), 1634567890);


CREATE TABLE ##EmailHistory_1634567890 (
    CampaignId INT,
    Recipient UNIQUEIDENTIFIER,
    Sender NVARCHAR(255),
    Timestamp DATETIME,
    CampaignEmailTemplateId INT
);

CREATE TABLE ##CampaignEmailTemplates_1634567890 (
    Id INT,
    CampaignId INT,
    WorkflowStep NVARCHAR(50),
    ccManager NVARCHAR(255)
);


EXEC tSQLt.NewTestClass @ClassName = N'tests_1634567890';
GO
EXEC tSQLt.NewTestClass 'tests_1634567892';


CREATE PROCEDURE [tests_1634567892].[ValidCampaignWithRecipient_1634567892]
AS
BEGIN
    DROP TABLE IF EXISTS ##EmailHistory_1634567892_1;
    DROP TABLE IF EXISTS ##CampaignEmailTemplates_1634567892_1;

    CREATE TABLE ##EmailHistory_1634567892_1 (
        CampaignId INT,
        Recipient NVARCHAR(50),
        Sender NVARCHAR(50),
        Timestamp DATETIME,
        CampaignEmailTemplateId INT
    );

    CREATE TABLE ##CampaignEmailTemplates_1634567892_1 (
        Id INT,
        CampaignId INT,
        WorkflowStep NVARCHAR(50),
        ccManager NVARCHAR(50)
    );

    INSERT INTO ##EmailHistory_1634567892_1 (CampaignId, Recipient, Sender, Timestamp, CampaignEmailTemplateId)
    VALUES (1, 'A1B2C3D4-E5F6-7890-ABCD-EF1234567892_1', 'sender1@example.com', GETDATE(), 1);

    INSERT INTO ##CampaignEmailTemplates_1634567892_1 (Id, CampaignId, WorkflowStep, ccManager)
    VALUES (1, 1, 'Step1', 'manager1@example.com');
    
    EXEC arm.GetEmailDetails @CampaignId = 1, @userStsGuid = 'A1B2C3D4-E5F6-7890-ABCD-EF1234567892_1';

    SELECT * INTO #Actual_1634567892_1 FROM ##EmailHistory_1634567892_1 WHERE CampaignEmailTemplateId = 1;

    EXEC tSQLt.AssertEqualsTable @Expected = ##EmailHistory_1634567892_1, @Actual = #Actual_1634567892_1;
END;


CREATE PROCEDURE [tests_1634567892].[NullRecipient_1634567892]
AS
BEGIN
    DROP TABLE IF EXISTS ##EmailHistory_1634567892_2;
    DROP TABLE IF EXISTS ##CampaignEmailTemplates_1634567892_2;

    CREATE TABLE ##EmailHistory_1634567892_2 (
        CampaignId INT,
        Recipient NVARCHAR(50),
        Sender NVARCHAR(50),
        Timestamp DATETIME,
        CampaignEmailTemplateId INT
    );

    CREATE TABLE ##CampaignEmailTemplates_1634567892_2 (
        Id INT,
        CampaignId INT,
        WorkflowStep NVARCHAR(50),
        ccManager NVARCHAR(50)
    );

    INSERT INTO ##EmailHistory_1634567892_2 (CampaignId, Recipient, Sender, Timestamp, CampaignEmailTemplateId)
    VALUES (2, NULL, 'sender2@example.com', GETDATE(), 2);

    INSERT INTO ##CampaignEmailTemplates_1634567892_2 (Id, CampaignId, WorkflowStep, ccManager)
    VALUES (2, 2, 'Step2', 'manager2@example.com');
    
    EXEC arm.GetEmailDetails @CampaignId = 2, @userStsGuid = NULL;

    SELECT * INTO #Actual_1634567892_2 FROM ##EmailHistory_1634567892_2 WHERE Recipient IS NULL;

    EXEC tSQLt.AssertEqualsTable @Expected = ##EmailHistory_1634567892_2, @Actual = #Actual_1634567892_2;
END;


DROP TABLE IF EXISTS ##EmailHistory_1634567892_1;
DROP TABLE IF EXISTS ##EmailHistory_1634567892_2;
DROP TABLE IF EXISTS ##CampaignEmailTemplates_1634567892_1;
DROP TABLE IF EXISTS ##CampaignEmailTemplates_1634567892_2;
GO
