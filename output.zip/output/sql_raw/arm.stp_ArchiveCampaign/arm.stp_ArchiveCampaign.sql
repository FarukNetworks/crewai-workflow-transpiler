CREATE PROCEDURE [arm].[stp_ArchiveCampaign]
    @campaignId int,
    @archivedBy uniqueIdentifier
AS
BEGIN

    SET NOCOUNT ON;

	DECLARE @description NVARCHAR(MAX)	= 'Campaign Archived by ' + (select SamAccountName from dbo.ADobjectInfo where STSGuid = @archivedBy)
	DECLARE @archivedDate DATETIME = getdate();

    insert into arm.ArchivedCampaignResult(CampaignId, CampaignName, [TimeStamp], CampaignAssetId, AssetName, AssetType, Change, ConfirmedOwner, ReviewedItem, OriginalValue, NewValue, ReviewSubmissionId, Email, [Review Submitter], FilerName, DFSPath, SharePath)
    exec arm.stp_CampaignResults @campaignId = @campaignId, @forArchive = 1

	EXEC arm.stp_AddAuditRecord @ActionedBy=@archivedBy,
	@EventDescription=@description, @AssetOwner=@archivedBy, @CampaignId=@campaignId, @AffectedItem=@campaignId, @ItemType='Campaign', @Timestamp = @archivedDate

    insert into arm.ArchivedCampaignAuditLog(CampaignId, [TimeStamp], ActionedBy, ActionedName, AffectedItem, EventDescription, ItemType, NewValue, PreviousValue, AssetOwner, SharePath, AssetName)
    exec arm.stp_CampaignAuditResults  @campaignId = @campaignId, @forArchive = 1

    UPDATE arm.Campaigns SET
        Archived = 1,
        ArchivedBy = @archivedBy,
        ArchivedDate = @archivedDate
    WHERE Id = @campaignId

    UPDATE arm.CustomQuestions SET
        CampaignScope = -1
    WHERE CampaignScope = @campaignId
END