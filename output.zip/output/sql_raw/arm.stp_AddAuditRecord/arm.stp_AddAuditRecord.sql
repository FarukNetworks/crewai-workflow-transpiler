CREATE PROCEDURE [arm].[stp_AddAuditRecord]
	@ActionedBy UNIQUEIDENTIFIER=NULL,
	@Timestamp DATETIME,
	@EventDescription NVARCHAR(MAX),
	@AffectedItem NVARCHAR(1550)=NULL,
	@CampaignId INT=NULL,
	@ItemType NVARCHAR(50)=NULL,
	@PreviousValue NVARCHAR(MAX)=NULL,
	@NewValue NVARCHAR(MAX)=NULL,
	@AssetOwner UNIQUEIDENTIFIER=NULL,
	@AssetName NVARCHAR(1550)=NULL
AS
BEGIN
	IF(@ItemType='Collection')
	BEGIN
		SET @ItemType='Share'
	END

	DECLARE @owner NVARCHAR(256)=@AssetOwner
	IF(@AssetOwner IS NULL AND @ItemType IN ('Account', 'Group', 'Service Account', 'Group Policy')
		AND TRY_CONVERT(UNIQUEIDENTIFIER, @AffectedItem) IS NOT NULL)
	BEGIN
		SET @owner =(SELECT oo.ManagedBy FROM dbo.ADobjectInfo ado
		INNER JOIN dbo.ObjOwner oo ON oo.objectID=ado.UniqueID
		INNER JOIN dbo.EntityKey ek ON ek.EntID=oo.EntType
		WHERE ado.STSGuid=cast(@AffectedItem AS UNIQUEIDENTIFIER) AND ek.Entity=@ItemType)
	END
	ELSE IF(@AssetOwner IS NULL AND @ItemType IN ('Application', 'Server', 'AppRole', 'Share','Exchange'))
	BEGIN
		SET @owner =(SELECT oo.ManagedBy FROM dbo.ObjOwner oo
		INNER JOIN dbo.EntityKey ek ON ek.EntID=oo.EntType
		WHERE oo.objectID=@AffectedItem AND ek.Entity=@ItemType)
	END

	IF(@ItemType = 'Exchange')
	BEGIN
		SET @ItemType ='Mailbox'
	END
	IF(@ItemType='Share')
	BEGIN
		SET @ItemType='Collection'
	END
	IF(@ItemType='Service Account')
	BEGIN
		SET @ItemType='Account'
	END


	set @Timestamp = getdate()

	INSERT INTO [arm].[CampaignAuditLog] ([CampaignId],[Timestamp],[ActionedBy],[AffectedItem],[ItemType],[EventDescription],[PreviousValue],[NewValue],[AssetOwner],[AssetName])
	VALUES(@CampaignId,@Timestamp,@ActionedBy,@AffectedItem,@ItemType,@EventDescription,@PreviousValue,@NewValue,@owner,@AssetName)

END