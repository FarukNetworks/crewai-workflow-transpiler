CREATE PROCEDURE [arm].[GetEmailDetails]
	@CampaignId INT,
	@userStsGuid UNIQUEIDENTIFIER=NULL
AS
BEGIN

	SELECT eh.CampaignId,
		   eh.Recipient,
		   eh.Sender,
		   eh.Timestamp,
		   cet.Id as CampaignEmailTemplateId,
		   cet.WorkflowStep,
		   cet.ccManager
	FROM arm.EmailHistory eh
	INNER JOIN arm.CampaignEmailTemplates cet ON cet.CampaignId=eh.CampaignId AND cet.Id=eh.CampaignEmailTemplateId
	WHERE eh.CampaignId=@CampaignId AND (eh.Recipient=@userStsGuid OR @userStsGuid IS NULL)

END